#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
أداة متقدمة لتوليد كلمات المرور - بديل Crunch بلغة Python
"""

import itertools
import string
import argparse
import sys
import os
from datetime import datetime
import hashlib
import random
import math

class AdvancedPasswordGenerator:
    def __init__(self):
        self.char_sets = {
            'lower': string.ascii_lowercase,
            'upper': string.ascii_uppercase,
            'digits': string.digits,
            'symbols': '!@#$%^&*()_+-=[]{}|;:,.<>?',
            'arabic': 'ء-ي',  # سيتم تحويلها لاحقاً
            'hex': '0123456789abcdef',
            'binary': '01',
            'custom': ''
        }
        
        self.generated_count = 0
        self.output_file = None
        
    def setup_character_sets(self, options):
        """إعداد مجموعات الأحرف بناءً على الخيارات"""
        char_pool = ""
        
        if options.lowercase:
            char_pool += self.char_sets['lower']
        
        if options.uppercase:
            char_pool += self.char_sets['upper']
        
        if options.numbers:
            char_pool += self.char_sets['digits']
        
        if options.symbols:
            char_pool += self.char_sets['symbols']
        
        # تصحيح: استخدم options.hex بدلاً من options.hexadecimal
        if hasattr(options, 'hex') and options.hex:
            char_pool = self.char_sets['hex']
        
        if options.binary:
            char_pool = self.char_sets['binary']
        
        if options.custom_chars:
            char_pool = options.custom_chars
        
        if options.arabic:
            # توليد أحرف عربية (Unicode range)
            arabic_chars = ''.join(chr(i) for i in range(0x0600, 0x06FF))
            char_pool += arabic_chars
        
        if not char_pool:
            # الإعداد الافتراضي: أحرف صغيرة وأرقام
            char_pool = self.char_sets['lower'] + self.char_sets['digits']
        
        # إزالة التكرارات
        char_pool = ''.join(sorted(set(char_pool)))
        
        return char_pool
    
    def estimate_size(self, char_pool, min_len, max_len):
        """تقدير حجم الملف الناتج"""
        total = 0
        for length in range(min_len, max_len + 1):
            total += len(char_pool) ** length
        
        # تقدير الحجم بالبايت (تقريباً 2 بايت لكل حرف + سطر جديد)
        estimated_bytes = total * (max_len + 1) * 2
        
        # تحويل لوحدات مختلفة
        size_units = [
            ('بايت', 1),
            ('كيلوبايت', 1024),
            ('ميجابايت', 1024**2),
            ('جيجابايت', 1024**3),
            ('تيرابايت', 1024**4)
        ]
        
        for unit, divisor in size_units:
            if estimated_bytes < divisor * 1024 or unit == 'تيرابايت':
                size = estimated_bytes / divisor
                return total, size, unit
        
        return total, estimated_bytes, 'بايت'
    
    def generate_passwords(self, char_pool, min_len, max_len, output_file=None, 
                          max_count=None, pattern=None, start_string=None):
        """توليد كلمات المرور"""
        
        self.output_file = output_file
        self.generated_count = 0
        
        # فتح ملف الإخراج إذا كان محدداً
        f = None
        if output_file:
            try:
                f = open(output_file, 'w', encoding='utf-8')
                print(f"📁 جاري الكتابة في: {output_file}")
            except Exception as e:
                print(f"❌ خطأ في فتح الملف: {e}")
                return False
        
        try:
            # إظهار تقدم التوليد للمدى الطويل
            show_progress = (max_len >= 4 or len(char_pool) ** max_len > 10000)
            
            for length in range(min_len, max_len + 1):
                if max_count and self.generated_count >= max_count:
                    break
                
                print(f"🔢 توليد كلمات بطول {length}...")
                
                # توليد جميع التوليفات الممكنة
                combinations = itertools.product(char_pool, repeat=length)
                
                for combo in combinations:
                    if max_count and self.generated_count >= max_count:
                        break
                    
                    password = ''.join(combo)
                    
                    # تطبيق النمط إذا كان محدداً
                    if pattern:
                        if len(password) != len(pattern):
                            continue
                        match = True
                        for p_char, pass_char in zip(pattern, password):
                            if p_char == '?' or p_char == pass_char:
                                continue
                            else:
                                match = False
                                break
                        if not match:
                            continue
                    
                    # البدء من سلسلة محددة إذا كانت موجودة
                    if start_string:
                        if password < start_string:
                            continue
                    
                    self.generated_count += 1
                    
                    # كتابة إلى الملف أو الطباعة
                    if f:
                        f.write(password + '\n')
                    else:
                        print(password)
                    
                    # إظهار التقدم
                    if show_progress and self.generated_count % 10000 == 0:
                        print(f"📊 تم توليد: {self.generated_count:,} كلمة...")
            
            if f:
                f.close()
                print(f"✅ تم حفظ {self.generated_count:,} كلمة في الملف")
            
            return True
            
        except KeyboardInterrupt:
            print("\n⏹️ تم إيقاف العملية من قبل المستخدم")
            if f:
                f.close()
            return False
        except Exception as e:
            print(f"❌ حدث خطأ: {e}")
            if f:
                f.close()
            return False
    
    def generate_with_pattern(self, pattern, char_pool, output_file=None, max_count=None):
        """توليد كلمات مرور بنمط محدد"""
        self.output_file = output_file
        self.generated_count = 0
        
        # تحليل النمط
        positions = []
        for char in pattern:
            if char == '?':
                positions.append(char_pool)
            else:
                positions.append(char)
        
        # حساب العدد الإجمالي
        total = 1
        for pos in positions:
            if isinstance(pos, str) and len(pos) > 1:
                total *= len(pos)
        
        print(f"🎯 النمط: {pattern}")
        print(f"📊 العدد الإجمالي المتوقع: {total:,}")
        
        # فتح ملف الإخراج إذا كان محدداً
        f = None
        if output_file:
            try:
                f = open(output_file, 'w', encoding='utf-8')
            except Exception as e:
                print(f"❌ خطأ في فتح الملف: {e}")
                return False
        
        try:
            # توليد جميع الاحتمالات
            combinations = itertools.product(*positions)
            
            for combo in combinations:
                if max_count and self.generated_count >= max_count:
                    break
                
                password = ''.join(combo)
                self.generated_count += 1
                
                if f:
                    f.write(password + '\n')
                else:
                    print(password)
                
                # إظهار التقدم
                if total > 10000 and self.generated_count % 10000 == 0:
                    print(f"📊 تم توليد: {self.generated_count:,} / {total:,} ...")
            
            if f:
                f.close()
                print(f"✅ تم حفظ {self.generated_count:,} كلمة في الملف")
            
            return True
            
        except KeyboardInterrupt:
            print("\n⏹️ تم إيقاف العملية")
            if f:
                f.close()
            return False
        except Exception as e:
            print(f"❌ حدث خطأ: {e}")
            if f:
                f.close()
            return False
    
    def generate_random(self, char_pool, count, min_len, max_len, output_file=None):
        """توليد كلمات مرور عشوائية"""
        self.output_file = output_file
        self.generated_count = 0
        
        # فتح ملف الإخراج إذا كان محدداً
        f = None
        if output_file:
            try:
                f = open(output_file, 'w', encoding='utf-8')
            except Exception as e:
                print(f"❌ خطأ في فتح الملف: {e}")
                return False
        
        try:
            print(f"🎲 توليد {count:,} كلمة عشوائية...")
            
            generated = set()  # لمنع التكرار
            
            for i in range(count):
                length = random.randint(min_len, max_len)
                password = ''.join(random.choice(char_pool) for _ in range(length))
                
                # التأكد من عدم التكرار
                while password in generated:
                    password = ''.join(random.choice(char_pool) for _ in range(length))
                
                generated.add(password)
                self.generated_count += 1
                
                if f:
                    f.write(password + '\n')
                else:
                    print(password)
                
                # إظهار التقدم
                if count > 1000 and i % 1000 == 0:
                    print(f"📊 تم توليد: {i:,} / {count:,} ...")
            
            if f:
                f.close()
                print(f"✅ تم حفظ {self.generated_count:,} كلمة عشوائية في الملف")
            
            return True
            
        except KeyboardInterrupt:
            print("\n⏹️ تم إيقاف العملية")
            if f:
                f.close()
            return False
        except Exception as e:
            print(f"❌ حدث خطأ: {e}")
            if f:
                f.close()
            return False
    
    def generate_from_dict(self, dict_file, output_file=None, max_count=None, 
                          min_len=None, max_len=None, mutate=False):
        """توليد كلمات مرور من قاموس مع إمكانية التحوير"""
        self.output_file = output_file
        self.generated_count = 0
        
        if not os.path.exists(dict_file):
            print(f"❌ ملف القاموس غير موجود: {dict_file}")
            return False
        
        # فتح ملف الإخراج إذا كان محدداً
        f = None
        if output_file:
            try:
                f = open(output_file, 'w', encoding='utf-8')
            except Exception as e:
                print(f"❌ خطأ في فتح الملف: {e}")
                return False
        
        try:
            print(f"📖 قراءة القاموس: {dict_file}")
            
            with open(dict_file, 'r', encoding='utf-8', errors='ignore') as dict_f:
                words = [line.strip() for line in dict_f if line.strip()]
            
            print(f"📊 عدد الكلمات في القاموس: {len(words):,}")
            
            mutations = []
            if mutate:
                # قواعد التحوير
                mutations = [
                    lambda w: w,  # الأصل
                    lambda w: w.upper(),
                    lambda w: w.lower(),
                    lambda w: w.capitalize(),
                    lambda w: w + '123',
                    lambda w: w + '!@#',
                    lambda w: '123' + w,
                    lambda w: w[::-1],  # عكس الكلمة
                    lambda w: w.replace('a', '@').replace('e', '3').replace('i', '1').replace('o', '0'),
                ]
            
            for word in words:
                if max_count and self.generated_count >= max_count:
                    break
                
                # التحقق من الطول إذا كان محدداً
                if min_len and len(word) < min_len:
                    continue
                if max_len and len(word) > max_len:
                    continue
                
                if mutate:
                    for mutate_func in mutations:
                        if max_count and self.generated_count >= max_count:
                            break
                        
                        mutated = mutate_func(word)
                        if mutated and (min_len is None or len(mutated) >= min_len) and \
                           (max_len is None or len(mutated) <= max_len):
                            
                            self.generated_count += 1
                            if f:
                                f.write(mutated + '\n')
                            else:
                                print(mutated)
                else:
                    self.generated_count += 1
                    if f:
                        f.write(word + '\n')
                    else:
                        print(word)
                
                # إظهار التقدم
                if len(words) > 10000 and self.generated_count % 10000 == 0:
                    print(f"📊 تم معالجة: {self.generated_count:,} كلمة...")
            
            if f:
                f.close()
                print(f"✅ تم حفظ {self.generated_count:,} كلمة في الملف")
            
            return True
            
        except KeyboardInterrupt:
            print("\n⏹️ تم إيقاف العملية")
            if f:
                f.close()
            return False
        except Exception as e:
            print(f"❌ حدث خطأ: {e}")
            if f:
                f.close()
            return False

def display_banner():
    """عرض شعار البرنامج"""
    banner = """
    ╔══════════════════════════════════════════════════════════╗
    ║   🔐 مولد كلمات المرور المتقدم - Advanced Password Generator   ║
    ║                     بديل Crunch بلغة Python                    ║
    ╚══════════════════════════════════════════════════════════╝
    """
    print(banner)

def main():
    parser = argparse.ArgumentParser(
        description='أداة متقدمة لتوليد كلمات المرور - بديل Crunch',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    # الخيارات الأساسية
    parser.add_argument('min_len', type=int, nargs='?', help='الحد الأدنى لطول كلمة المرور')
    parser.add_argument('max_len', type=int, nargs='?', help='الحد الأقصى لطول كلمة المرور')
    
    # خيارات أنواع الأحرف
    parser.add_argument('-t', '--lowercase', action='store_true', help='استخدام الأحرف الصغيرة (a-z)')
    parser.add_argument('-u', '--uppercase', action='store_true', help='استخدام الأحرف الكبيرة (A-Z)')
    parser.add_argument('-n', '--numbers', action='store_true', help='استخدام الأرقام (0-9)')
    parser.add_argument('-s', '--symbols', action='store_true', help='استخدام الرموز الخاصة (!@#$...)')
    parser.add_argument('--hex', action='store_true', help='استخدام النظام الست عشري (0-9, a-f)')
    parser.add_argument('--binary', action='store_true', help='استخدام النظام الثنائي (0-1)')
    parser.add_argument('--arabic', action='store_true', help='استخدام الأحرف العربية')
    parser.add_argument('-c', '--custom-chars', type=str, help='مجموعة أحرف مخصصة')
    
    # خيارات التوليد
    parser.add_argument('-o', '--output', type=str, help='ملف الإخراج')
    parser.add_argument('-p', '--pattern', type=str, help='نمط التوليد (مثال: pass???)')
    parser.add_argument('-r', '--random', type=int, help='عدد كلمات المرور العشوائية')
    parser.add_argument('-d', '--dictionary', type=str, help='ملف قاموس للاستخدام')
    parser.add_argument('-m', '--mutate', action='store_true', help='تحوير كلمات القاموس')
    parser.add_argument('-l', '--limit', type=int, help='الحد الأقصى لعدد كلمات المرور')
    parser.add_argument('--start', type=str, help='بدء التوليد من سلسلة محددة')
    
    # خيارات إضافية
    parser.add_argument('-e', '--estimate', action='store_true', help='تقدير الحجم فقط دون التوليد')
    parser.add_argument('-v', '--verbose', action='store_true', help='وضع التفصيل')
    parser.add_argument('--version', action='store_true', help='عرض رقم الإصدار')
    
    args = parser.parse_args()
    
    if args.version:
        print("مولد كلمات المرور المتقدم - الإصدار 3.0")
        return
    
    display_banner()
    
    generator = AdvancedPasswordGenerator()
    
    # إذا كان المستخدم يريد تقدير الحجم فقط
    if args.estimate:
        if not args.min_len or not args.max_len:
            print("❌ يجب تحديد الحد الأدنى والأقصى للطول مع خيار -e")
            return
        
        char_pool = generator.setup_character_sets(args)
        
        if not char_pool:
            print("❌ يجب تحديد نوع واحد على الأقل من الأحرف")
            return
        
        total, size, unit = generator.estimate_size(char_pool, args.min_len, args.max_len)
        
        print(f"\n📊 تقدير الإحصائيات:")
        print(f"   مجموع الأحرف المتاحة: {len(char_pool)}")
        print(f"   الطول: من {args.min_len} إلى {args.max_len} حرف")
        print(f"   العدد الإجمالي المحتمل: {total:,}")
        print(f"   الحجم المتوقع: {size:,.2f} {unit}")
        
        if size > 1024**3:  # أكبر من 1 جيجابايت
            print("⚠️  تحذير: الحجم المتوقع كبير جداً!")
            confirm = input("هل تريد المتابعة؟ (y/N): ")
            if confirm.lower() != 'y':
                return
        
        return
    
    # إذا كان المستخدم يريد توليد من قاموس
    if args.dictionary:
        if not os.path.exists(args.dictionary):
            print(f"❌ ملف القاموس غير موجود: {args.dictionary}")
            return
        
        print(f"\n📖 بدء التوليد من القاموس: {args.dictionary}")
        
        min_len = args.min_len if args.min_len else 1
        max_len = args.max_len if args.max_len else 999
        
        generator.generate_from_dict(
            args.dictionary,
            args.output,
            args.limit,
            min_len,
            max_len,
            args.mutate
        )
        
        return
    
    # التحقق من المدخلات الأساسية
    if not args.min_len or not args.max_len:
        if not args.pattern and not args.random:
            print("❌ يجب تحديد الحد الأدنى والأقصى للطول")
            print("\nاستخدم --help لعرض المساعدة")
            return
    
    # إعداد مجموعات الأحرف
    char_pool = generator.setup_character_sets(args)
    
    if not char_pool:
        print("❌ يجب تحديد نوع واحد على الأقل من الأحرف")
        return
    
    # عرض معلومات البداية
    print(f"\n🎯 إعدادات التوليد:")
    print(f"   مجموع الأحرف: {len(char_pool)}")
    
    if args.pattern:
        print(f"   النمط: {args.pattern}")
    elif args.random:
        print(f"   العدد: {args.random:,} كلمة عشوائية")
        print(f"   الطول: من {args.min_len} إلى {args.max_len}")
    else:
        print(f"   الطول: من {args.min_len} إلى {args.max_len} حرف")
    
    if args.limit:
        print(f"   الحد الأقصى: {args.limit:,}")
    
    if args.output:
        print(f"   الملف: {args.output}")
    
    # تقدير الحجم للعمليات الكبيرة
    if not args.random and args.min_len and args.max_len:
        total, size, unit = generator.estimate_size(char_pool, args.min_len, args.max_len)
        
        if args.limit:
            total = min(total, args.limit)
        
        if total > 0:
            print(f"\n📊 الإحصائيات المتوقعة:")
            print(f"   العدد الإجمالي: {total:,}")
            
            if total > 1000000:
                print("⚠️  تحذير: العدد كبير جداً!")
                confirm = input("هل تريد المتابعة؟ (y/N): ")
                if confirm.lower() != 'y':
                    return
    
    # بدء التوليد
    print("\n⚡ بدء عملية التوليد...")
    print("=" * 50)
    
    try:
        if args.pattern:
            # توليد بنمط محدد
            success = generator.generate_with_pattern(
                args.pattern,
                char_pool,
                args.output,
                args.limit
            )
        
        elif args.random:
            # توليد عشوائي
            success = generator.generate_random(
                char_pool,
                args.random,
                args.min_len,
                args.max_len,
                args.output
            )
        
        else:
            # توليد منهجي
            success = generator.generate_passwords(
                char_pool,
                args.min_len,
                args.max_len,
                args.output,
                args.limit,
                args.pattern,
                args.start
            )
        
        if success:
            print("\n" + "=" * 50)
            print(f"✅ اكتمل التوليد بنجاح!")
            print(f"📊 العدد الإجمالي: {generator.generated_count:,}")
            
            if args.output:
                if os.path.exists(args.output):
                    file_size = os.path.getsize(args.output)
                    size_units = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت']
                    
                    for i, unit in enumerate(size_units):
                        if file_size < 1024**(i+1) or i == len(size_units)-1:
                            size = file_size / (1024**i)
                            print(f"📁 حجم الملف: {size:.2f} {unit}")
                            break
            
            if generator.generated_count == 0:
                print("⚠️  لم يتم توليد أي كلمات. تحقق من الإعدادات.")
        
        else:
            print("\n❌ فشل عملية التوليد")
    
    except KeyboardInterrupt:
        print("\n\n⏹️ تم إيقاف البرنامج من قبل المستخدم")
        if generator.generated_count > 0:
            print(f"📊 تم توليد: {generator.generated_count:,} كلمة قبل الإيقاف")
    
    except Exception as e:
        print(f"\n❌ حدث خطأ غير متوقع: {e}")

if __name__ == "__main__":
    main()
